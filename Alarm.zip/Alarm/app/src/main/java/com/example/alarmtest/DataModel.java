package com.example.alarmtest;
//s1880159 Chao Chen
public class DataModel {

    String time;

    public DataModel(String time) {

        this.time = time;
    }

    public String getTime() {
        return time;
    }
}
